<div class="card mb-4">
    <div class="card-header bg-primary  text-light fw-bold text-center py-3">Cari Artikel</div>
    <div class="card-body">
        <div class="input-group">
            <input class="form-control" type="text" placeholder="Masukan Judul Artikel"
                aria-label="Enter search term..." aria-describedby="button-search" />
            <button class="btn btn-primary" id="button-search" type="button">Cari</button>
        </div>
    </div>
</div>
