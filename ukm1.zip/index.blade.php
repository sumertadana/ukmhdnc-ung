<?php header(‘Location: public/’);
