<?php $__env->startSection('konten'); ?>
    <?php
    use App\Models\Pengurus;
    use App\Models\Bidang;
    use App\Models\Jabatan;
    use App\Models\Anggota;
    ?>
    <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bdg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1 class="fs-3 fw-bold text-center mb-3 mt-3"><?php echo e($bdg->bidang); ?></h1>
        <?php
            $anggota = Pengurus::join('anggota', 'pengurus.nim', 'anggota.nim')
                ->join('jabatan', 'pengurus.id_jabatan', 'jabatan.id')
                ->select('anggota.nama', 'anggota.foto', 'jabatan.jabatan')
                ->where('pengurus.id_bidang', $bdg->id)
                ->get();
        ?>
        <div class="row py-3 container-fluid">
            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-4 col-lg-3 px-0 my-1">
                    <div class="card mx-2 shadow">
                        <img src="<?php echo e(asset('assets/img/anggota/' . $agt->foto)); ?>" class="card-img-top img-fluid"
                            alt="<?php echo e($agt->foto); ?>">
                        <div class="card-body pt-2">
                            <h1 class="card-title fs-5 text-center fw-bold"><?php echo e($agt->jabatan); ?></h1>
                            <h1 class="card-text fs-6 text-center text-secondary"><?php echo e($agt->nama); ?></h1>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.users.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukm\resources\views/users/pengurus.blade.php ENDPATH**/ ?>