<?php
use App\Models\Bidang;
$bidang = Bidang::where('bidang', '!=', 'Pengurus Inti')->get();
?>
<div class="card mb-4">
    <div class="card-header  bg-primary text-light fw-bold text-center py-3">Kategori Bidang</div>
    <div class="card-body">
        <ul class="list-unstyled mb-0 row">
            <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bdg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="col-md-12 col-sm-6"><a href="<?php echo e(route('caribidang', $bdg->bidang)); ?>"
                        class="text-decoration-none"><?php echo e($bdg->bidang); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ukm\resources\views/layouts/users/bidang.blade.php ENDPATH**/ ?>