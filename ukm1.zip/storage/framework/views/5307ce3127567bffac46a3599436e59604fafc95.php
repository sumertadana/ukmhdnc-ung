<!-- Search widget-->

<!-- pengurus widget-->
<?php echo $__env->make('layouts.users.pengurus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Categories Bidang widget-->
<?php echo $__env->make('layouts.users.bidang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Galeri widget-->
<?php echo $__env->make('layouts.users.galeri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ukm\resources\views/layouts/users/sidebar.blade.php ENDPATH**/ ?>