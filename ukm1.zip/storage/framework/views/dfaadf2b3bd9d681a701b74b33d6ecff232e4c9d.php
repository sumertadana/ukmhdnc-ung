<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Blog Home - Start Bootstrap Template</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo e(asset('assets/css/home-styles.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/mystyle.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">



</head>

<body>
    <!-- Responsive navbar-->
    <nav class="navbar navbar-expand-md navbar-dark bg-primary sticky-top shadow-lg pb-0 my-0">
        <div class="container">
            <a class="navbar-brand my-md-1 py-0 my-0" href="#!">
                <img src="<?php echo e(asset('assets/img/logo/logo-depan.png')); ?>" class="mb-1 mt-sm-0 img-fluid" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 fw-bold">
                    <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(url('/')); ?>">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="#!">Struktur</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="#!">Galeri</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="#">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Page header with logo and tagline-->
    <header class=" bg-white mb-md-3 ">
        <div class="owl-carousel" id="slider-carousel">
            <div> <img class="img-fluid item" src="<?php echo e(asset('assets/img/slider/20221.png')); ?>" alt=""> </div>
            <div> <img class="img-fluid item" src="<?php echo e(asset('assets/img/slider/20221.png')); ?>" alt=""> </div>
            <div> <img class="img-fluid item" src="<?php echo e(asset('assets/img/slider/20221.png')); ?>" alt=""> </div>
        </div>
    </header>
    <!-- Page content-->
    <div class="container">
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-8">
                <?php echo $__env->yieldContent('konten'); ?>
            </div>
            <!-- Side widgets-->
            <div class="col-lg-4">
                <!-- Search widget-->
                <div class="card mb-4">
                    <div class="card-header bg-primary  text-light fw-bold text-center py-3">Cari Artikel</div>
                    <div class="card-body">
                        <div class="input-group">
                            <input class="form-control" type="text" placeholder="Masukan Judul Artikel"
                                aria-label="Enter search term..." aria-describedby="button-search" />
                            <button class="btn btn-primary" id="button-search" type="button">Cari</button>
                        </div>
                    </div>
                </div>
                <!-- pengurus widget-->
                <?php
                    use App\Models\Pengurus;
                    $sidepengurus = Pengurus::all();
                ?>
                <div class="card border-0">
                    <div class="card-header bg-primary text-light fw-bold text-center py-3">Struktur Organisasi</div>
                    <div class="card-body p-0">
                        <div class="owl-carousel" id="slider-pengurus">
                            <?php $__currentLoopData = $sidepengurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div> <img class="img-fluid item"
                                        src="<?php echo e(asset('assets/img/pengurus/' . $spgr->foto)); ?>"
                                        alt="<?php echo e($spgr->nama); ?>"> </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <!-- Categories widget-->
                <?php
                    use App\Models\Bidang;
                    $bidang = Bidang::all();
                ?>
                <div class="card mb-4">
                    <div class="card-header  bg-primary text-light fw-bold text-center py-3">Kategori Bidang</div>
                    <div class="card-body">
                        <ul class="list-unstyled mb-0 row">
                            <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bdg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="col-6"><a href="#"
                                        class="text-decoration-none"><?php echo e($bdg->bidang); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <!-- Side widget-->
                <?php
                    use App\Models\Berita;
                    $sidegaleri = Berita::all();
                ?>
                <div class="card border-0 mb-4">
                    <div class="card-header bg-primary text-light fw-bold text-center py-3">Galeri Kegiatan</div>
                    <div class="card-body p-0">
                        <div class="owl-carousel" id="slider-galeri">
                            <?php $__currentLoopData = $sidegaleri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sglr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <img class="img-fluid item"
                                        src="<?php echo e(asset('assets/img/berita/' . $sglr->gambar)); ?>"
                                        alt="<?php echo e($sglr->judul); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer-->
    <footer class="py-4 bg-primary">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; UKM-HDNC UNG 2022</p>
        </div>
    </footer>
    <!-- Core theme JS-->
    <script src="<?php echo e(asset('assets/js/home-scripts.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>


    <script>
        $(document).ready(function() {
            $('#slider-carousel').owlCarousel({
                responsive: {
                    0: {
                        items: 1
                    },
                    640: {
                        items: 1
                    },
                    800: {
                        items: 1
                    }
                },
                pagination: false,
                navigation: false,
                margin: 10,
                loop: true,
                autoplay: true,
                autoplayTimeout: 5000,
                center: true,
                autoWidth: false,
            });
        });
        $(document).ready(function() {
            $('#slider-pengurus').owlCarousel({
                responsive: {
                    0: {
                        items: 1
                    }
                },
                pagination: false,
                navigation: false,
                margin: 0,
                loop: true,
                autoplay: true,
                autoplayTimeout: 5000,
                center: true,
                autoWidth: false,
            });
        });
        $(document).ready(function() {
            $('#slider-galeri').owlCarousel({
                responsive: {
                    0: {
                        items: 1
                    }
                },
                pagination: false,
                navigation: false,
                margin: 0,
                loop: true,
                autoplay: true,
                autoplayTimeout: 5000,
                center: true,
                autoWidth: false,
            });
        });
    </script>



</body>

</html>
<?php /**PATH C:\xampp\htdocs\ukm\resources\views/layouts/user.blade.php ENDPATH**/ ?>