<?php $__env->startSection('konten'); ?>
    <h1 class="fs-3 fw-bold text-center mb-4 mt-2">Galeri Kegiatan</h1>
    <div class="row mb-3">
        <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $glr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-4 col-lg-3 px-2 mb-3">
                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                    data-bs-target="#tampil<?php echo e($glr->id); ?>">
                    <img src="<?php echo e(asset('assets/img/galeri/' . $glr->foto)); ?>" class="img-fluid" alt="">
                </button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $glr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="tampil<?php echo e($glr->id); ?>" tabindex="-1" aria-hidden="false" id="staticBackdrop"
            data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-body p-0">
                        <div class="ratio ratio-4x3">
                            <iframe src="<?php echo e(asset('assets/img/galeri/' . $glr->foto)); ?>" title="YouTube video"
                                allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.users.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukm\resources\views/users/galeri.blade.php ENDPATH**/ ?>