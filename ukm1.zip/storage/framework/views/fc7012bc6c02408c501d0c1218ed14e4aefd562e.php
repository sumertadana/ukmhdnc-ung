<?php $__env->startSection('konten'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Anggota</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert">×</button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-error">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert">×</button>
        </div>
    <?php endif; ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <button type="button" class="btn btn-primary shadow" data-toggle="modal" data-target="#tambah">Tambah
                Data</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table dataTable table-bordered" id="myTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>Nama</th>
                            <th>NIM</th>
                            <th>JK</th>
                            <th>Angkatan</th>
                            <th>Fakultas</th>
                            <th>Jurusan</th>
                            <th>Alamat</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($agt->nama); ?></td>
                                <td><?php echo e($agt->nim); ?></td>
                                <td>
                                    <?php switch($agt->jk):
                                        case ('Laki-Laki'): ?>
                                            L
                                        <?php break; ?>

                                        <?php default: ?>
                                            P
                                    <?php endswitch; ?>
                                </td>
                                <td><?php echo e($agt->angkatan); ?></td>
                                <td><?php echo e($agt->fakultas); ?></td>
                                <td><?php echo e($agt->jurusan); ?></td>
                                <td><?php echo e($agt->alamat); ?></td>
                                <td><?php echo e($agt->status); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary shadow mb-1" data-toggle="modal"
                                        data-target="#edit<?php echo e($agt->id); ?>"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-danger shadow" data-toggle="modal"
                                        data-target="#hapus<?php echo e($agt->id); ?>"><i class="fa fa-trash-alt"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal tambah data-->
    <div class="modal fade" id="tambah" tabindex="-1" aria-hidden="true" id="staticBackdrop" data-backdrop="static"
        data-keyboard="false">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modelHeading">Tambah Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal" enctype="multipart/form-data" method="POST"
                        action="<?php echo e(route('tambahanggota')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-sm-6">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control required" id="nama" name="nama"
                                    placeholder="Masukan Nama" value="" minlength="2" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="nim">NIM</label>
                                <input type="text" class="form-control required" id="nim" name="nim"
                                    placeholder="Masukan NIM" value="" minlength="9" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="fakultas">Fakultas</label>
                                <input type="text" class="form-control required" id="fakultas" name="fakultas"
                                    placeholder="Masukan Fakultas" value="" minlength="2" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="jurusan">Jurusan</label>
                                <input type="text" class="form-control required" id="jurusan" name="jurusan"
                                    placeholder="Masukan Jurusan" value="" minlength="2" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="angkatan">Angkatan</label>
                                <input type="text" class="form-control required" id="angkatan" name="angkatan"
                                    placeholder="Masukan Angkatan" value="" minlength="4" maxlength="4" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="status">Status Anggota</label>
                                <input type="text" class="form-control required" id="status" name="status"
                                    placeholder="Masukan Status Anggota" value="" minlength="2" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="alamat">Alamat</label>
                                <input type="text" class="form-control required" id="alamat" name="alamat"
                                    placeholder="Masukan Alamat" value="" minlength="2" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="jk">Jenis Kelamin</label>
                                <select name="jk" id="jk" class="form-control">
                                    <option value="Laki-Laki">Laki-Laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary" value="create">Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal ubah data-->
        <div class="modal fade" id="edit<?php echo e($agt->id); ?>" tabindex="-1" aria-hidden="true" id="staticBackdrop"
            data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modelHeading">Ubah Data</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" enctype="multipart/form-data" method="POST"
                            action="<?php echo e(route('updateanggota', $agt->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" id="id" value="<?php echo e($agt->id); ?>">
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label for="nama">Nama</label>
                                    <input type="text" class="form-control required" id="nama" name="nama"
                                        value="<?php echo e($agt->nama); ?>" minlength="2" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="nim">NIM</label>
                                    <input type="text" class="form-control required" id="nim" name="nim"
                                        value="<?php echo e($agt->nim); ?>" minlength="9" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="fakultas">Fakultas</label>
                                    <input type="text" class="form-control required" id="fakultas" name="fakultas"
                                        value="<?php echo e($agt->fakultas); ?>" minlength="2" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="jurusan">Jurusan</label>
                                    <input type="text" class="form-control required" id="jurusan" name="jurusan"
                                        value="<?php echo e($agt->jurusan); ?>" minlength="2" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="angkatan">Angkatan</label>
                                    <input type="text" class="form-control required" id="angkatan" name="angkatan"
                                        value="<?php echo e($agt->angkatan); ?>" minlength="4" maxlength="4" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="status">Status Anggota</label>
                                    <input type="text" class="form-control required" id="status" name="status"
                                        value="<?php echo e($agt->status); ?>" minlength="2" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="alamat">Alamat</label>
                                    <input type="text" class="form-control required" id="alamat" name="alamat"
                                        value="<?php echo e($agt->alamat); ?>" minlength="2" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="jk">Jenis Kelamin</label>
                                    <select name="jk" id="jk" class="form-control">
                                        <option value="<?php echo e($agt->jk); ?>" hidden><?php echo e($agt->jk); ?></option>
                                        <option value="Laki-Laki">Laki-Laki</option>
                                        <option value="Perempuan">Perempuan</option>
                                    </select>
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" value="create">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- modal hapus -->
        <div class="modal fade" id="hapus<?php echo e($agt->id); ?>" tabindex="-1" aria-hidden="true" id="staticBackdrop"
            data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modelHeading">Hapus Data</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah anda yakin akan menghapus data <?php echo e($agt->nama); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <a href="<?php echo e(route('hapusanggota', $agt->id)); ?>" type="button" class="btn btn-danger">Hapus</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ukm\resources\views/admin/anggota.blade.php ENDPATH**/ ?>