<?php $__env->startSection('konten'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Pengurus</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert">×</button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-error">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert">×</button>
        </div>
    <?php endif; ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <button type="button" class="btn btn-primary shadow" data-toggle="modal" data-target="#tambah">Tambah
                Data</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table dataTable table-bordered" id="myTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>NIM</th>
                            <th>Bidang</th>
                            <th>Jabatan</th>
                            <th>Periode</th>
                            <th>Foto</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pengurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($pgr->nama); ?></td>
                                <td><?php echo e($pgr->nim); ?></td>
                                <td><?php echo e($pgr->bidang); ?></td>
                                <td><?php echo e($pgr->jabatan); ?></td>
                                <td><?php echo e($pgr->periode); ?></td>
                                <td><img src="<?php echo e(asset('assets/img/pengurus/' . $pgr->foto)); ?>" alt="" width="50"></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary shadow" data-toggle="modal"
                                        data-target="#edit<?php echo e($pgr->id); ?>"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-danger shadow" data-toggle="modal"
                                        data-target="#hapus<?php echo e($pgr->id); ?>"><i class="fa fa-trash-alt"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal tambah data-->
    <div class="modal fade" id="tambah" tabindex="-1" aria-hidden="true" id="staticBackdrop" data-backdrop="static"
        data-keyboard="false">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modelHeading">Tambah Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal" enctype="multipart/form-data" method="POST"
                        action="<?php echo e(route('kirimpengurus')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-sm-6">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control required" id="namaT" name="nama"
                                    placeholder="Masukan Nama" value="" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="nim">NIM</label>
                                <input type="text" class="form-control required" id="nimT" name="nim"
                                    placeholder="Masukan NIM" value="" minlength="9" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="bidang">Bidang</label>
                                <select name="bidang" id="bidangT" class="form-control required">
                                    <option selected>--- Pilih Bidang ---</option>
                                    <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bd->bidang); ?>"><?php echo e($bd->bidang); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="jabatan">Jabatan</label>
                                <select name="jabatan" id="jabatanT" class="form-control required">
                                    <option selected>--- Pilih Jabatan ---</option>
                                </select>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="periode">Periode</label>
                                <input type="text" class="form-control required" id="periode" name="periode"
                                    placeholder="Masukan periode" value="" minlength="2" required="">
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="foto">Foto</label>
                                <input type="file" class="form-control required" id="foto" name="foto" value="" required>
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary" value="create">Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Ubah data-->
    <?php $__currentLoopData = $pengurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="edit<?php echo e($pgr->id); ?>" tabindex="-1" aria-hidden="true" id="staticBackdrop"
            data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modelHeading">Ubah Data</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" enctype="multipart/form-data" method="POST"
                            action="<?php echo e(route('updatepengurus', $pgr->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label for="nama">Nama</label>
                                    <input type="text" class=" nama form-control required" id="namaU" name="nama"
                                        value="<?php echo e($pgr->nama); ?>" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="nim">NIM</label>
                                    <input type="text" class="form-control required" id="nimU" name="nim"
                                        value="<?php echo e($pgr->nim); ?>" minlength="9" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="bidang">Bidang</label>
                                    <select name="bidang" id="bidangU" class="form-control required">
                                        <option selected value="<?php echo e($pgr->bidang); ?>" hidden><?php echo e($pgr->bidang); ?></option>
                                        <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bd->bidang); ?>"><?php echo e($bd->bidang); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="jabatan">Jabatan</label>
                                    <select name="jabatan" id="jabatanU" class="form-control required">
                                        <option selected value="<?php echo e($pgr->jabatan); ?>" hidden><?php echo e($pgr->jabatan); ?>

                                        </option>
                                    </select>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="periode">Periode</label>
                                    <input type="text" class="form-control required" id="periode" name="periode"
                                        value="<?php echo e($pgr->periode); ?>" minlength="4" required="">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="foto">Foto</label>
                                    <input type="file" class="form-control" id="foto" name="foto" value="">
                                    <small id="note" class="form-text text-muted">Kosongkan Jika Tidak Ingin Mengubah
                                        Foto</small>
                                </div>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" value="create">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- modal hapus -->
        <div class="modal fade" id="hapus<?php echo e($pgr->id); ?>" tabindex="-1" aria-hidden="true" id="staticBackdrop"
            data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modelHeading">Hapus Data</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah anda yakin akan menghapus data <?php echo e($pgr->nama); ?> dari pengurus</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <a href="<?php echo e(route('hapuspengurus', $pgr->id)); ?>" type="button" class="btn btn-danger">Hapus</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.min.js"
        integrity="sha256-eGE6blurk5sHj+rmkfsGYeKyZx3M4bG+ZlFyA7Kns7E=" crossorigin="anonymous"></script>
    <script>
        $(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            // TAMBAH
            $(function() {
                $('#bidangT').on('change', function() {
                    let kode = $('#bidangT').val();

                    $.ajax({
                        type: 'POST',
                        url: '<?php echo e(route('carijabatan')); ?>',
                        data: {
                            kode: kode
                        },
                        cache: false,

                        success: function(msg) {
                            $('#jabatanT').html(msg);
                        },

                    })
                })
            });
            // UBAH
            $(function() {
                $('#bidangU').on('change', function() {
                    let kode = $('#bidangU').val();

                    $.ajax({
                        type: 'POST',
                        url: '<?php echo e(route('carijabatan')); ?>',
                        data: {
                            kode: kode
                        },
                        cache: false,

                        success: function(msg) {
                            $('#jabatanU').html(msg);
                        },

                    })
                })
            });
            // TAMBAH
            $(function() {
                $('#namaT').on('change', function() {
                    let nama = $('#namaT').val();

                    $.ajax({
                        type: 'POST',
                        url: '<?php echo e(route('carianggota')); ?>',
                        data: {
                            nama: nama
                        },
                        cache: false,

                        success: function(response) {
                            if (response == "nothing") {
                                alert("DATA ANGGOTA TIDAK DITEMUKAN");
                            } else {
                                document.getElementById("nimT").value = response[0].nim;
                                document.getElementById("namaT").value = response[0]
                                    .nama;
                            }
                        },

                    })
                })
            });
            // UPDATE
            $(function() {
                $('#namaU').on('change', function() {
                    let nama = $('#namaU').val();

                    $.ajax({
                        type: 'POST',
                        url: '<?php echo e(route('carianggota')); ?>',
                        data: {
                            nama: nama
                        },
                        cache: false,

                        success: function(response) {
                            if (response == "nothing") {
                                alert("DATA ANGGOTA TIDAK DITEMUKAN");
                            } else {
                                document.getElementById("nimU").value = response[0].nim;
                                document.getElementById("namaU").value = response[0]
                                    .nama;
                            }
                        },

                    })
                })
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukm\resources\views/admin/pengurus.blade.php ENDPATH**/ ?>