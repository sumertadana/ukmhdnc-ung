<?php
use App\Models\Pengurus;
// $sidepengurus = Pengurus::all();
$sidepengurus = Pengurus::join('anggota', 'pengurus.nim', 'anggota.nim')
    ->join('jabatan', 'pengurus.id_jabatan', 'jabatan.id')
    ->select('anggota.nama', 'anggota.foto', 'jabatan.jabatan')
    // ->where('pengurus.id_bidang', $bdg->id)
    ->get();
?>
<div class="card border-0">
    <div class="card-header bg-primary text-light fw-bold text-center py-3">Pengurus Organisasi</div>
    <div class="card-body p-0">
        <div class="owl-carousel" id="slider-pengurus">
            <?php $__currentLoopData = $sidepengurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div> <img class="img-fluid item" src="<?php echo e(asset('assets/img/anggota/' . $spgr->foto)); ?>"
                        alt="<?php echo e($spgr->nama); ?>"> </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script>

</script>
<?php /**PATH C:\xampp\htdocs\ukm\resources\views/layouts/users/pengurus.blade.php ENDPATH**/ ?>