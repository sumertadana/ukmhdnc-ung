<?php $__env->startSection('konten'); ?>
    <!-- Blog entries-->
    <div class="col-md-9">
        <?php switch($x):
            case (1): ?>
                <h2 class="text-start fw-bold h5 mb-4">Menampilkan hasil artikel tentang "<?php echo e($cari); ?>" </h2>
                <?php echo $__env->make('layouts.users.berita', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

            <?php case (2): ?>
                <h2 class="text-start fw-bold h5 mb-4">Tidak dapat menemukan artikel tentang "<?php echo e($cari); ?>" </h2>
            <?php break; ?>

            <?php case (3): ?>
                <h2 class="text-start fw-bold h5 mb-4">Menampilkan hasil artikel tentang bidang "<?php echo e($bidang->bidang); ?>" </h2>
                <?php echo $__env->make('layouts.users.berita', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

            <?php case (4): ?>
                <h2 class="text-start fw-bold h5 mb-4">Tidak dapat menemukan artikel bidang "<?php echo e($bidang->bidang); ?>" </h2>
            <?php break; ?>

            <?php default: ?>
                <h2 class="text-start fw-bold h5 mb-4">Program Kerja Terlaksana <i class="fab fa-chromecast"></i></h2>
                <?php echo $__env->make('layouts.users.berita', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endswitch; ?>

    </div>
    <!-- Side widgets-->
    <div class="col-md-3">
        <?php echo $__env->make('layouts.users.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.users.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukm\resources\views/users/index.blade.php ENDPATH**/ ?>