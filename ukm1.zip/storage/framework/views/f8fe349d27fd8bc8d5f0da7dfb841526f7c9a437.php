<?php
use App\Models\Galeri;
$sidegaleri = Galeri::all();
?>
<div class="card border-0 mb-4">
    <div class="card-header bg-primary text-light fw-bold text-center py-3">Galeri Kegiatan</div>
    <div class="card-body p-0">
        <div class="owl-carousel" id="slider-galeri">
            <?php $__currentLoopData = $sidegaleri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sglr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <img class="img-fluid item" src="<?php echo e(asset('assets/img/galeri/' . $sglr->foto)); ?>"
                        alt="<?php echo e($sglr->judul); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ukm\resources\views/layouts/users/galeri.blade.php ENDPATH**/ ?>