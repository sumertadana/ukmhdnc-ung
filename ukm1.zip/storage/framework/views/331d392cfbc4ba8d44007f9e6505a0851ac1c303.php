<?php
use App\Models\Komentar;
use App\Models\Komentar2;
?>
<div class="card mb-3 border-0 bg-light">
    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row g-0 mb-4">
            <div class="col-md-4">
                <img src="<?php echo e(asset('assets/img/berita/' . $brt->gambar)); ?>"
                    class="img-fluid rounded-start mt-0 border-1" alt="<?php echo e($brt->judul); ?>">
            </div>
            <div class="col-md-8 ">
                <div class="card-body pt-md-0 ps-md-3 px-0">
                    <a class="card-title fw-bold h4 mb-1 text-dark text-decoration-none text-uppercase" strong
                        href="<?php echo e(route('tampil-berita', $brt->judul)); ?>"><?php echo e($brt->judul); ?></a>
                    <p class="card-text text-justify mb-1 text-secondary">
                        <?php
                            echo substr($brt->deskripsi, 0, 250) . '...';
                        ?>
                        <a class="mb-0" href="<?php echo e(route('tampil-berita', $brt->judul)); ?>">selengkapnya</a>
                    </p>
                    <p class="card-text mt-0">
                        <a class="badge bg-warning text-decoration-none link-light me-2"
                            href="<?php echo e(route('caribidang', $brt->bidang)); ?>"><?php echo e($brt->bidang); ?></a>
                        <small class="text-muted me-2"><i class="fa fa-calendar-alt"></i>
                            <?php echo e(date('d F Y', strtotime($brt->created_at))); ?>

                        </small>
                        <?php
                            $jumlahkomen1 = Komentar::where('id_berita', $brt->id)->get();
                            $jumlahkomen2 = Komentar2::where('id_berita', $brt->id)->get();
                            $jumlah = count($jumlahkomen1) + count($jumlahkomen2);
                        ?>
                        <small class="text-muted me-2"><i class="fas fa-comments"></i> <?php echo e($jumlah); ?></small>
                        <small class="text-muted"><i class="fa fa-eye mr-1"></i> <?php echo e($brt->view); ?></small>
                    </p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\ukm\resources\views/layouts/users/berita.blade.php ENDPATH**/ ?>