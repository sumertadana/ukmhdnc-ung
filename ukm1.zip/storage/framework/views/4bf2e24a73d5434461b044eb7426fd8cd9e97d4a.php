<?php $__env->startSection('konten'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Inventaris</h1>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-error">
        <?php echo e(session('error')); ?>

        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
<?php endif; ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <button type="button" class="btn btn-primary shadow" data-toggle="modal" data-target="#tambah">Tambah Data</button>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table dataTable table-bordered" id="myTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Kode</th>
                        <th>Jumlah</th>
                        <th>Kondisi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $inventaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($inv->nama); ?></td>
                        <td><?php echo e($inv->kode); ?></td>
                        <td><?php echo e($inv->jumlah); ?></td>
                        <td><?php echo e($inv->kondisi); ?></td>
                        <td>
                            <button type="button" class="btn btn-sm btn-primary shadow" data-toggle="modal" data-target="#edit<?php echo e($inv->id); ?>"><i class="fa fa-edit"></i></button>
                            <button type="button" class="btn btn-sm btn-danger shadow" data-toggle="modal" data-target="#hapus<?php echo e($inv->id); ?>"><i class="fa fa-trash-alt"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal tambah data-->
<div class="modal fade" id="tambah" tabindex="-1" aria-hidden="true" id="staticBackdrop" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="modelHeading">Tambah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
            <form class="form-horizontal" enctype="multipart/form-data" method="POST" action="<?php echo e(route('tambahinventaris')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="form-group col-sm-12">
                        <label for="nama" >Nama</label>
                        <input type="text" class="form-control required" id="nama" name="nama" placeholder="Masukan Nama" value=""  minlength="2" required="">
                    </div>
                    <div class="form-group col-sm-12">
                        <label for="kode" >Kode</label>
                        <input type="text" class="form-control required" id="kode" name="kode" placeholder="Masukan Kode" value=""  minlength="2"  required="">
                    </div>
                    <div class="form-group col-sm-12">
                        <label for="jumlah" >Jumlah</label>
                        <input type="text" class="form-control required" id="jumlah" name="jumlah" placeholder="Masukan Jumlah" value=""  minlength="2" required="">
                    </div>
                    <div class="form-group col-sm-12">
                        <label for="kondisi" >Kondisi</label>
                        <select name="kondisi" id="kondisi" class="form-control">
                            <option value="Baik">Baik</option>
                            <option value="Cukup">Cukup</option>
                            <option value="Rusak">Rusak</option>
                        </select>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary" value="create">Simpan</button>
            </div>
        </form>
    </div>
    </div>
</div>

<?php $__currentLoopData = $inventaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal ubah data-->
<div class="modal fade" id="edit<?php echo e($inv->id); ?>" tabindex="-1" aria-hidden="true" id="staticBackdrop" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="modelHeading">Ubah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
            <form class="form-horizontal" enctype="multipart/form-data" method="POST" action="<?php echo e(route('updateinventaris', $inv->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="form-group col-sm-12">
                        <label for="nama" >Nama</label>
                        <input type="text" class="form-control required" id="nama" name="nama" value="<?php echo e($inv->nama); ?>"  minlength="2" required="">
                    </div>
                    <div class="form-group col-sm-12">
                        <label for="kode" >Kode</label>
                        <input type="text" class="form-control required" id="kode" name="kode" value="<?php echo e($inv->kode); ?>"  minlength="2"  required="">
                    </div>
                    <div class="form-group col-sm-12">
                        <label for="jumlah" >Jumlah</label>
                        <input type="text" class="form-control required" id="jumlah" name="jumlah" value="<?php echo e($inv->jumlah); ?>"  minlength="2" required="">
                    </div>
                    <div class="form-group col-sm-12">
                        <label for="kondisi" >Kondisi</label>
                        <select name="kondisi" id="kondisi" class="form-control">
                            <option value="<?php echo e($inv->kondisi); ?>" hidden><?php echo e($inv->kondisi); ?></option>
                            <option value="Baik">Baik</option>
                            <option value="Cukup">Cukup</option>
                            <option value="Rusak">Rusak</option>
                        </select>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary" value="create">Simpan</button>
            </div>
        </form>
    </div>
    </div>
</div>

<!-- modal hapus -->
<div class="modal fade" id="hapus<?php echo e($inv->id); ?>" tabindex="-1" aria-hidden="true" id="staticBackdrop" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="modelHeading">Hapus Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
            <p>Apakah anda yakin akan menghapus data <?php echo e($inv->nama); ?></p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
            <a href="<?php echo e(route('hapusinventaris', $inv->id)); ?>" type="button" class="btn btn-danger">Hapus</a>
        </div>
    </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ukm\resources\views/admin/inventaris.blade.php ENDPATH**/ ?>