<header class=" bg-white mb-md-3 ">
    <?php
        use App\Models\Slider;
        $slider = Slider::all();
    ?>
    <div class="owl-carousel mt-2 container-fluid" id="slider-carousel">
        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div> <img class="item shadow" src="<?php echo e(asset('assets/img/slider/' . $sld->gambar)); ?>"
                    alt="<?php echo e($sld->judul); ?>"> </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\ukm\resources\views/layouts/users/header.blade.php ENDPATH**/ ?>